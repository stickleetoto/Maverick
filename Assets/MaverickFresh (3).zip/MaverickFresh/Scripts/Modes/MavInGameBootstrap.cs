using UnityEngine;

namespace MaverickFresh
{
    public class MavInGameBootstrap : MonoBehaviour
    {
        [Header("Optional real aircraft prefabs")]
        public GameObject f15Prefab;
        public GameObject f16Prefab;
        public GameObject fa18Prefab;
        public GameObject f22Prefab;
        public GameObject f35Prefab;

        [Header("Startup")]
        public bool setupOnStart = true;
        public bool useSessionSelection = true;
        public MavAircraftKind fallbackAircraft = MavAircraftKind.F22A;
        public MavGameMode fallbackMode = MavGameMode.FreeFlight;
        public bool createEnvironment = true;
        public bool spawnModeTargets = true;
        public bool installCAS = true;
        public bool installPhysicalAI = true;

        [Header("Created")]
        public GameObject aircraftObject;
        public MavAircraftRuntimeProfile activeProfile;
        public MavFreshBootstrap freshBootstrap;
        public MavAircraftProfileApplier profileApplier;
        public MavInGameMenuOverlay menuOverlay;

        private void Start()
        {
            if (setupOnStart)
                SetupInGame();
        }

        [ContextMenu("Setup In-Game")]
        public void SetupInGame()
        {
            MavAircraftKind aircraft = useSessionSelection && MavGameSession.HasSelection ? MavGameSession.SelectedAircraft : fallbackAircraft;
            MavGameMode mode = useSessionSelection ? MavGameSession.SelectedMode : fallbackMode;
            activeProfile = MavAircraftCatalog.GetBuiltIn(aircraft);

            if (createEnvironment)
                BuildEnvironment();

            Camera cam = EnsureCamera();
            aircraftObject = MavAircraftVisualFactory.CreateFlightAircraftRoot(activeProfile, GetPrefab(aircraft));
            aircraftObject.transform.position = new Vector3(0f, activeProfile.startAltitude, 0f);
            aircraftObject.transform.rotation = Quaternion.identity;

            Rigidbody rb = aircraftObject.GetComponent<Rigidbody>();
            if (rb == null)
                rb = aircraftObject.AddComponent<Rigidbody>();

            freshBootstrap = gameObject.GetComponent<MavFreshBootstrap>();
            if (freshBootstrap == null)
                freshBootstrap = gameObject.AddComponent<MavFreshBootstrap>();

            freshBootstrap.setupOnAwake = false;
            freshBootstrap.aircraftObject = aircraftObject;
            freshBootstrap.mainCamera = cam;
            freshBootstrap.installCASStarter = installCAS;
            freshBootstrap.installPhysicalAIStarter = installPhysicalAI && (mode == MavGameMode.Dogfight || mode == MavGameMode.FreeFlight);
            freshBootstrap.applyAirStart = true;
            freshBootstrap.startAltitude = activeProfile.startAltitude;
            freshBootstrap.startSpeed = activeProfile.startSpeed;
            freshBootstrap.startEulerAngles = Vector3.zero;
            freshBootstrap.jetThrust = activeProfile.thrust;
            freshBootstrap.mouseSensitivity = activeProfile.mouseSensitivity;
            freshBootstrap.aimDistance = activeProfile.aimDistance;
            freshBootstrap.SetupFreshMouseFlight();

            profileApplier = aircraftObject.GetComponent<MavAircraftProfileApplier>();
            if (profileApplier == null)
                profileApplier = aircraftObject.AddComponent<MavAircraftProfileApplier>();
            profileApplier.applyOnStart = false;
            profileApplier.ApplyProfile(activeProfile);

            rb.linearVelocity = aircraftObject.transform.forward * activeProfile.startSpeed;
            rb.angularVelocity = Vector3.zero;

            if (spawnModeTargets)
                BuildMode(mode);

            menuOverlay = cam.GetComponent<MavInGameMenuOverlay>();
            if (menuOverlay == null)
                menuOverlay = cam.gameObject.AddComponent<MavInGameMenuOverlay>();
            menuOverlay.profile = activeProfile;
            menuOverlay.mode = mode;
        }

        private Camera EnsureCamera()
        {
            Camera cam = Camera.main;
            if (cam == null)
            {
                GameObject camGo = new GameObject("Main Camera");
                cam = camGo.AddComponent<Camera>();
                cam.tag = "MainCamera";
            }
            cam.enabled = true;
            cam.depth = 100;
            return cam;
        }

        private void BuildEnvironment()
        {
            if (GameObject.Find("Mav_InGame_Sun") == null)
            {
                GameObject lightGo = new GameObject("Mav_InGame_Sun");
                Light l = lightGo.AddComponent<Light>();
                l.type = LightType.Directional;
                l.intensity = 1.2f;
                lightGo.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
            }

            if (GameObject.Find("Mav_InGame_Ground") == null)
            {
                GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
                ground.name = "Mav_InGame_Ground";
                ground.transform.position = new Vector3(0f, -2f, 1600f);
                ground.transform.localScale = new Vector3(6000f, 1f, 6000f);
            }
        }

        private void BuildMode(MavGameMode mode)
        {
            if (mode == MavGameMode.TestRange || mode == MavGameMode.GroundAttack)
            {
                MavCASTestRangeSpawner range = gameObject.GetComponent<MavCASTestRangeSpawner>();
                if (range == null)
                    range = gameObject.AddComponent<MavCASTestRangeSpawner>();
                range.buildOnStart = false;
                range.targetRows = mode == MavGameMode.GroundAttack ? 3 : 2;
                range.targetsPerRow = mode == MavGameMode.GroundAttack ? 6 : 5;
                range.rangeCenter = new Vector3(0f, 0f, 1800f);
                range.BuildRange();
            }

            if (mode == MavGameMode.Dogfight || mode == MavGameMode.FreeFlight)
            {
                MavAirTargetSpawner air = gameObject.GetComponent<MavAirTargetSpawner>();
                if (air == null)
                    air = gameObject.AddComponent<MavAirTargetSpawner>();
                air.buildOnStart = false;
                air.droneCount = mode == MavGameMode.Dogfight ? 5 : 3;
                air.centerAltitude = activeProfile != null ? activeProfile.startAltitude - 250f : 900f;
                air.BuildTargets();
            }

            if (mode == MavGameMode.CarrierTest)
                BuildCarrierPlaceholder();
        }

        private void BuildCarrierPlaceholder()
        {
            GameObject carrier = GameObject.Find("Mav_Carrier_Prototype");
            if (carrier != null) return;

            carrier = GameObject.CreatePrimitive(PrimitiveType.Cube);
            carrier.name = "Mav_Carrier_Prototype";
            carrier.transform.position = new Vector3(0f, 2f, 2200f);
            carrier.transform.localScale = new Vector3(90f, 8f, 360f);

            GameObject deck = GameObject.CreatePrimitive(PrimitiveType.Cube);
            deck.name = "Mav_Carrier_Deck_Line";
            deck.transform.SetParent(carrier.transform, true);
            deck.transform.position = carrier.transform.position + new Vector3(0f, 5f, 0f);
            deck.transform.localScale = new Vector3(8f, 0.25f, 340f);
        }

        private GameObject GetPrefab(MavAircraftKind kind)
        {
            if (kind == MavAircraftKind.F15E) return f15Prefab;
            if (kind == MavAircraftKind.F16C) return f16Prefab;
            if (kind == MavAircraftKind.FA18E) return fa18Prefab;
            if (kind == MavAircraftKind.F22A) return f22Prefab;
            if (kind == MavAircraftKind.F35A) return f35Prefab;
            return null;
        }
    }
}
