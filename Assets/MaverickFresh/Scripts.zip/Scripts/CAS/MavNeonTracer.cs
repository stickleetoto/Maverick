using UnityEngine;

namespace MaverickFresh
{
    /// <summary>
    /// Tiny self-cleaning neon line tracer used by the fast gun pass.
    /// </summary>
    [DisallowMultipleComponent]
    public class MavNeonTracer : MonoBehaviour
    {
        public LineRenderer line;
        public float life = 0.045f;
        public float startWidth = 0.045f;
        public float endWidth = 0.012f;
        public Color startColor = new Color(0.15f, 0.95f, 1f, 1f);
        public Color endColor = new Color(1f, 0.35f, 0.08f, 0.25f);

        private float spawnTime;

        public static MavNeonTracer Spawn(Vector3 start, Vector3 end, float duration, float width, Color color)
        {
            GameObject go = new GameObject("Mav_Neon_Gun_Tracer");
            MavNeonTracer tracer = go.AddComponent<MavNeonTracer>();
            tracer.life = Mathf.Max(0.005f, duration);
            tracer.startWidth = Mathf.Max(0.002f, width);
            tracer.endWidth = Mathf.Max(0.001f, width * 0.25f);
            tracer.startColor = color;
            tracer.endColor = new Color(color.r, color.g, color.b, 0f);
            tracer.Initialize(start, end);
            return tracer;
        }

        public void Initialize(Vector3 start, Vector3 end)
        {
            spawnTime = Time.time;
            line = gameObject.AddComponent<LineRenderer>();
            line.useWorldSpace = true;
            line.positionCount = 2;
            line.SetPosition(0, start);
            line.SetPosition(1, end);
            line.startWidth = startWidth;
            line.endWidth = endWidth;
            line.numCapVertices = 4;
            line.numCornerVertices = 2;

            Shader shader = Shader.Find("Sprites/Default");
            if (shader == null)
                shader = Shader.Find("Unlit/Color");
            if (shader == null)
                shader = Shader.Find("Standard");

            Material mat = new Material(shader);
            mat.color = startColor;
            line.material = mat;
            line.startColor = startColor;
            line.endColor = endColor;
        }

        private void Update()
        {
            float t = Mathf.Clamp01((Time.time - spawnTime) / Mathf.Max(0.001f, life));
            if (line != null)
            {
                Color c0 = startColor;
                Color c1 = endColor;
                c0.a *= 1f - t;
                c1.a *= 1f - t;
                line.startColor = c0;
                line.endColor = c1;
                line.startWidth = Mathf.Lerp(startWidth, 0f, t);
                line.endWidth = Mathf.Lerp(endWidth, 0f, t);
            }

            if (t >= 1f)
                Destroy(gameObject);
        }
    }
}
