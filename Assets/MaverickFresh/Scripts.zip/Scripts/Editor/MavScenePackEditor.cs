#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MaverickFresh.EditorTools
{
    public static class MavScenePackEditor
    {
        private const string ScenesFolder = "Assets/MaverickFresh/Scenes";

        [MenuItem("Maverick/Create Three-Scene Game Pack")]
        public static void CreateThreeSceneGamePack()
        {
            EnsureFolder("Assets", "MaverickFresh");
            EnsureFolder("Assets/MaverickFresh", "Scenes");

            string lobbyPath = ScenesFolder + "/" + MavSceneNames.MainLobby + ".unity";
            string hangarPath = ScenesFolder + "/" + MavSceneNames.Hangar + ".unity";
            string inGamePath = ScenesFolder + "/" + MavSceneNames.InGame + ".unity";

            CreateLobbyScene(lobbyPath);
            CreateHangarScene(hangarPath);
            CreateInGameScene(inGamePath);
            AddScenesToBuildSettings(new string[] { lobbyPath, hangarPath, inGamePath });

            EditorUtility.DisplayDialog(
                "Maverick Scene Pack Created",
                "Created three separate scenes:\n\n" +
                "1. " + MavSceneNames.MainLobby + "\n" +
                "2. " + MavSceneNames.Hangar + "\n" +
                "3. " + MavSceneNames.InGame + "\n\n" +
                "They were also added to Build Settings. Open Mav_MainLobby and press Play.",
                "OK"
            );
        }

        private static void CreateLobbyScene(string path)
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject root = new GameObject("Maverick_MainLobby_Bootstrap");
            root.AddComponent<MavMainLobbyBootstrap>();
            EditorSceneManager.SaveScene(scene, path);
        }

        private static void CreateHangarScene(string path)
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject root = new GameObject("Maverick_Hangar_Bootstrap");
            root.AddComponent<MavHangarBootstrap>();
            EditorSceneManager.SaveScene(scene, path);
        }

        private static void CreateInGameScene(string path)
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject root = new GameObject("Maverick_InGame_Bootstrap");
            root.AddComponent<MavInGameBootstrap>();
            EditorSceneManager.SaveScene(scene, path);
        }

        private static void EnsureFolder(string parent, string child)
        {
            string path = parent + "/" + child;
            if (!AssetDatabase.IsValidFolder(path))
                AssetDatabase.CreateFolder(parent, child);
        }

        private static void AddScenesToBuildSettings(string[] paths)
        {
            List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>();
            for (int i = 0; i < paths.Length; i++)
                scenes.Add(new EditorBuildSettingsScene(paths[i], true));

            EditorBuildSettings.scenes = scenes.ToArray();
        }
    }
}
#endif
