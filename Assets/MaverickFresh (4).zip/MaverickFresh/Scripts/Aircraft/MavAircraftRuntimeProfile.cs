using System;
using UnityEngine;

namespace MaverickFresh
{
    [Serializable]
    public class MavAircraftRuntimeProfile
    {
        [Header("Identity")]
        public MavAircraftKind aircraft;
        public string aircraftId;
        public string displayName;
        public string shortName;
        public string role;
        [TextArea(2, 5)] public string description;
        public GameObject modelPrefab;

        [Header("Hangar")]
        public float hangarScale = 1f;
        public Vector3 hangarRotationEuler = new Vector3(0f, 145f, 0f);
        public Vector3 hangarCameraOffset = new Vector3(0f, 3.2f, -11f);


        [Header("Flight Visual Pose")]
        public Vector3 flightVisualLocalPosition = Vector3.zero;
        public Vector3 flightVisualLocalEuler = Vector3.zero;
        public float flightVisualScale = 1f;

        [Header("Stats 0~10")]
        [Range(0f, 10f)] public float statSpeed = 7f;
        [Range(0f, 10f)] public float statTurn = 7f;
        [Range(0f, 10f)] public float statStability = 7f;
        [Range(0f, 10f)] public float statPayload = 5f;
        [Range(0f, 10f)] public float statDifficulty = 5f;

        [Header("Rigidbody")]
        public float mass = 14500f;
        public float linearDamping = 0.021f;
        public float angularDamping = 1.6f;
        public float maxAngularVelocity = 6f;

        [Header("Speed / Engine")]
        public float startAltitude = 1200f;
        public float startSpeed = 260f;
        public float thrust = 220f;
        public float throttlePercent = 95f;
        public float throttleChangeRate = 45f;
        public float throttleSpoolUp = 1.8f;
        public float throttleSpoolDown = 2.4f;
        public float afterburnerMultiplier = 1.35f;
        public float targetCruiseSpeed = 315f;
        public float minCombatSpeed = 135f;
        public float maxCombatSpeed = 530f;
        public float lowSpeedThrustBoost = 0.55f;
        public float overspeedDrag = 0.055f;
        public float speedAssistStrength = 0.22f;

        [Header("Mouse / Instructor")]
        public float mouseSensitivity = 3.85f;
        public float aimDistance = 600f;
        public float pitchGain = 0.82f;
        public float yawGain = 0.24f;
        public float rollGain = 1.25f;
        public float maxAutoPitch = 0.68f;
        public float noseDownTrim = 0.115f;
        public float inputSmoothing = 5.8f;
        public float maxScreenRollBankAngle = 72f;
        public float targetPitchRateDeg = 48f;
        public float targetYawRateDeg = 18f;
        public float targetRollRateDeg = 72f;
        public Vector3 rateControlP = new Vector3(0.42f, 0.28f, 0.38f);
        public Vector3 rateControlD = new Vector3(0.10f, 0.12f, 0.09f);
        public Vector3 maxRateControlTorque = new Vector3(32f, 14f, 40f);

        [Header("Torque")]
        public Vector3 turnTorque = new Vector3(20f, 9f, 26f);
        public Vector3 forceModeTorque = new Vector3(6200f, 3200f, 8200f);
        public Vector3 maxAppliedTorqueAccelerationMode = new Vector3(42f, 18f, 52f);
        public Vector3 maxAppliedTorqueForceMode = new Vector3(9000f, 4200f, 10500f);
        public float forceMult = 1000f;

        [Header("Envelope")]
        public float bestTurnSpeed = 236f;
        public float turnBandWidth = 95f;
        public float bestTurnPitchBoost = 1.28f;
        public float bestTurnRollBoost = 1.12f;
        public float lowSpeedPitchAuthority = 0.58f;
        public float bestSpeedPitchAuthority = 1.15f;
        public float highSpeedPitchAuthority = 0.72f;
        public float lowSpeedRollAuthority = 0.70f;
        public float bestSpeedRollAuthority = 1.05f;
        public float highSpeedRollAuthority = 0.82f;
        public float softGLimit = 8.8f;
        public float hardGLimit = 11.2f;
        public float aoaSoftLimitDeg = 24f;
        public float aoaHardLimitDeg = 34f;
        public float aoaPitchReduction = 0.45f;

        [Header("Manual / Keyboard")]
        public float manualPitchBoost = 2.75f;
        public float manualRollBoost = 1.05f;
        public float keyboardYawAuthority = 0.55f;
        public float keyboardElevatorResponse = 34f;
        public float keyboardElevatorReleaseBlend = 8.5f;

        [Header("Weapons / Arcade Loadout")]
        public int gunAmmo = 950;
        public int missileAmmo = 4;
        public int precisionAmmo = 4;
        public int bombAmmo = 6;
        public int rocketAmmo = 28;
        public float gunMuzzleSpeed = 960f;
        public float missileMaxSpeed = 780f;
        public float missileMaxTurnRateDeg = 50f;

        public MavAircraftRuntimeProfile Clone()
        {
            return (MavAircraftRuntimeProfile)MemberwiseClone();
        }
    }
}
